﻿using System;
using System.IO;
using UnityEngine;
using UnityInjector.Attributes;
using GearMenu;
using System.Drawing.Imaging;

namespace AutoCompileSample.Plugin
{
	[PluginName( "AutoCompileSample" )]
    [PluginVersion("0.0.0.0")]
    public class AutoCompileSample : PluginExt.ExPluginBase
	{
		// アイコンのバイナリ
		public byte[] IconPng { get; protected set; }
		// ボタンの管理名
		public string ButtonName { get { return "AutoCompileSample"; } }
		// ボタンにホバーした際のラベル
		public string Label { get { return "AutoCompileSample" + ((m_isEnable) ? ("ON") : ("OFF"));  } }

		private bool m_isEnable = true;

		public AutoCompileSample()
		{
			// リソースからアイコンをロード
			MemoryStream ms = new MemoryStream();
			Properties.Resources.SampleIcon.Save( ms, ImageFormat.Png );
			IconPng = ms.GetBuffer();
		}


		// メニュークリック時のコールバック
		private void OnGearMenuClick( GameObject gameObject )
		{
			m_isEnable = !m_isEnable;

			if ( m_isEnable )
			{
				Buttons.SetFrameColor( gameObject, Color.red );
			}
			else
			{
				Buttons.SetFrameColor( gameObject, new Color( 0.827f, 0.827f, 0.827f ) );
			}

			// ラベル再設定
			Buttons.SetText( gameObject, Label );
		}

		private void OnLevelWasLoaded( int level )
		{
			Console.WriteLine( Properties.Resources.SampleMsg );
			_registerGearButton();
		}

		// ボタンを登録
		private void _registerGearButton()
		{
			if ( Buttons.Contains( ButtonName ) )
			{
				Buttons.Remove( ButtonName );
			}
			GameObject btn = Buttons.Add( ButtonName, Label, IconPng, OnGearMenuClick );

			if ( m_isEnable )
			{
				Buttons.SetFrameColor( btn, Color.red );
			}
			else
			{
				Buttons.SetFrameColor( btn, new Color( 0.827f, 0.827f, 0.827f ) );
			}
		}
	}
}
